﻿Module Module1

    Sub main()
        Dim CuboidVolume As Double
        Dim answer As Boolean
        Console.WriteLine("Enter C to calculate volume of a Cuboid, or S to alternatively calculate the volume of a sphere:")
        answer = Console.ReadLine()

        If answer = "C" Or answer = "Cuboid" Then
            CuboidVolume



        End If


    End Sub

    'this is a function (functions return a value)
    Public Function CuboidVolume(ByVal l As Integer, ByVal w As Integer, ByVal h As Integer)


        CuboidVolume = l * w * h


        Console.WriteLine("Enter a length:")
        l = Console.ReadLine()

        Console.WriteLine("Enter a width:")
        w = Console.ReadLine()

        Console.WriteLine("Enter a height:")
        h = Console.ReadLine()
        Return CuboidVolume
    End Function









End Module
