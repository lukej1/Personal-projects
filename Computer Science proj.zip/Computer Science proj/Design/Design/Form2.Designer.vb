﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.buySellButton = New System.Windows.Forms.Button()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.PEcomboBox = New System.Windows.Forms.ComboBox()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.helpButton2 = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnDisplayData = New System.Windows.Forms.Button()
        Me.StockExchangeDataSet1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StockExchangeBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.StockExchangeDataSet1 = New Design.stockExchangeDataSet1()
        Me.StockExchangeDataSet1BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.searchBox = New System.Windows.Forms.TextBox()
        Me.spotlightSearch = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBoxID = New System.Windows.Forms.TextBox()
        Me.TextBoxSymbol = New System.Windows.Forms.TextBox()
        Me.TextBoxCompanyName = New System.Windows.Forms.TextBox()
        Me.TextBoxMarketingSector = New System.Windows.Forms.TextBox()
        Me.TextBoxPE = New System.Windows.Forms.TextBox()
        Me.TextBoxCountry = New System.Windows.Forms.TextBox()
        Me.TextBoxIndustry = New System.Windows.Forms.TextBox()
        Me.TextBoxVolume = New System.Windows.Forms.TextBox()
        Me.TextBoxChange = New System.Windows.Forms.TextBox()
        Me.TextBoxPrice = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TextBoxMktCap = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.quitButton = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.buyListing = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StockExchangeDataSet1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StockExchangeBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StockExchangeDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StockExchangeDataSet1BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(9, 421)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(54, 23)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Filters ▲"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'buySellButton
        '
        Me.buySellButton.BackColor = System.Drawing.Color.Purple
        Me.buySellButton.ForeColor = System.Drawing.SystemColors.Control
        Me.buySellButton.Location = New System.Drawing.Point(1109, 384)
        Me.buySellButton.Name = "buySellButton"
        Me.buySellButton.Size = New System.Drawing.Size(121, 51)
        Me.buySellButton.TabIndex = 32
        Me.buySellButton.Text = "Sell/Remove listing"
        Me.buySellButton.UseVisualStyleBackColor = False
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.Color.Purple
        Me.TextBox14.Location = New System.Drawing.Point(6, 416)
        Me.TextBox14.Multiline = True
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(585, 58)
        Me.TextBox14.TabIndex = 35
        '
        'ComboBox2
        '
        Me.ComboBox2.AccessibleName = "Company Name"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(69, 421)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 41
        Me.ComboBox2.Text = "Company Name"
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(196, 421)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 42
        Me.ComboBox3.Text = "Industry"
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(69, 448)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox4.TabIndex = 43
        Me.ComboBox4.Text = "Marketing Sector"
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(450, 422)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox5.TabIndex = 44
        Me.ComboBox5.Text = "Volume"
        '
        'PEcomboBox
        '
        Me.PEcomboBox.FormattingEnabled = True
        Me.PEcomboBox.Location = New System.Drawing.Point(323, 421)
        Me.PEcomboBox.Name = "PEcomboBox"
        Me.PEcomboBox.Size = New System.Drawing.Size(121, 21)
        Me.PEcomboBox.TabIndex = 46
        Me.PEcomboBox.Text = "PE"
        '
        'ComboBox8
        '
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Location = New System.Drawing.Point(196, 448)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox8.TabIndex = 47
        Me.ComboBox8.Text = "Country"
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(323, 448)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox9.TabIndex = 48
        Me.ComboBox9.Text = "Price"
        '
        'helpButton2
        '
        Me.helpButton2.BackColor = System.Drawing.Color.Red
        Me.helpButton2.ForeColor = System.Drawing.SystemColors.Control
        Me.helpButton2.Location = New System.Drawing.Point(3, 5)
        Me.helpButton2.Name = "helpButton2"
        Me.helpButton2.Size = New System.Drawing.Size(39, 33)
        Me.helpButton2.TabIndex = 72
        Me.helpButton2.Text = "help"
        Me.helpButton2.UseVisualStyleBackColor = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Cursor = System.Windows.Forms.Cursors.WaitCursor
        Me.Label15.Location = New System.Drawing.Point(1187, 25)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(10, 13)
        Me.Label15.TabIndex = 74
        Me.Label15.Text = "."
        Me.Label15.UseWaitCursor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(44, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 81)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 75
        Me.PictureBox1.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Purple
        Me.Label14.Location = New System.Drawing.Point(138, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(231, 25)
        Me.Label14.TabIndex = 76
        Me.Label14.Text = "Virtual stock exchange"
        '
        'btnDisplayData
        '
        Me.btnDisplayData.BackColor = System.Drawing.Color.Purple
        Me.btnDisplayData.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.btnDisplayData.Location = New System.Drawing.Point(476, 352)
        Me.btnDisplayData.Name = "btnDisplayData"
        Me.btnDisplayData.Size = New System.Drawing.Size(115, 38)
        Me.btnDisplayData.TabIndex = 79
        Me.btnDisplayData.Text = "Display/Update Data"
        Me.btnDisplayData.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(3, 83)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1153, 263)
        Me.DataGridView1.TabIndex = 80
        '
        'StockExchangeDataSet1
        '
        Me.StockExchangeDataSet1.DataSetName = "stockExchangeDataSet1"
        Me.StockExchangeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StockExchangeDataSet1BindingSource1
        '
        Me.StockExchangeDataSet1BindingSource1.DataSource = Me.StockExchangeDataSet1
        Me.StockExchangeDataSet1BindingSource1.Position = 0
        '
        'searchBox
        '
        Me.searchBox.Location = New System.Drawing.Point(111, 374)
        Me.searchBox.Name = "searchBox"
        Me.searchBox.Size = New System.Drawing.Size(100, 20)
        Me.searchBox.TabIndex = 81
        '
        'spotlightSearch
        '
        Me.spotlightSearch.AutoSize = True
        Me.spotlightSearch.BackColor = System.Drawing.Color.Indigo
        Me.spotlightSearch.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.spotlightSearch.Location = New System.Drawing.Point(19, 377)
        Me.spotlightSearch.Name = "spotlightSearch"
        Me.spotlightSearch.Size = New System.Drawing.Size(84, 13)
        Me.spotlightSearch.TabIndex = 82
        Me.spotlightSearch.Text = "spotlight search:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Purple
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label10.Location = New System.Drawing.Point(613, 384)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(24, 13)
        Me.Label10.TabIndex = 87
        Me.Label10.Text = "No."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Purple
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label5.Location = New System.Drawing.Point(806, 411)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 86
        Me.Label5.Text = "Industry"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Purple
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label3.Location = New System.Drawing.Point(613, 463)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 85
        Me.Label3.Text = "Marketing sector"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Purple
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Location = New System.Drawing.Point(613, 437)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 13)
        Me.Label2.TabIndex = 84
        Me.Label2.Text = "Company name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Purple
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label4.Location = New System.Drawing.Point(613, 410)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 83
        Me.Label4.Text = "Symbol"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Purple
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label9.Location = New System.Drawing.Point(954, 464)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(42, 13)
        Me.Label9.TabIndex = 92
        Me.Label9.Text = "Volume"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Purple
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label8.Location = New System.Drawing.Point(954, 437)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 91
        Me.Label8.Text = "Change"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Purple
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label7.Location = New System.Drawing.Point(954, 410)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 90
        Me.Label7.Text = "Price"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Purple
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label6.Location = New System.Drawing.Point(807, 438)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(43, 13)
        Me.Label6.TabIndex = 89
        Me.Label6.Text = "Country"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Purple
        Me.Label16.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label16.Location = New System.Drawing.Point(807, 463)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(26, 13)
        Me.Label16.TabIndex = 88
        Me.Label16.Text = "P/E"
        '
        'TextBoxID
        '
        Me.TextBoxID.Location = New System.Drawing.Point(705, 378)
        Me.TextBoxID.Name = "TextBoxID"
        Me.TextBoxID.ReadOnly = True
        Me.TextBoxID.Size = New System.Drawing.Size(22, 20)
        Me.TextBoxID.TabIndex = 93
        '
        'TextBoxSymbol
        '
        Me.TextBoxSymbol.Location = New System.Drawing.Point(705, 403)
        Me.TextBoxSymbol.Name = "TextBoxSymbol"
        Me.TextBoxSymbol.ReadOnly = True
        Me.TextBoxSymbol.Size = New System.Drawing.Size(62, 20)
        Me.TextBoxSymbol.TabIndex = 94
        '
        'TextBoxCompanyName
        '
        Me.TextBoxCompanyName.Location = New System.Drawing.Point(705, 430)
        Me.TextBoxCompanyName.Name = "TextBoxCompanyName"
        Me.TextBoxCompanyName.ReadOnly = True
        Me.TextBoxCompanyName.Size = New System.Drawing.Size(96, 20)
        Me.TextBoxCompanyName.TabIndex = 95
        '
        'TextBoxMarketingSector
        '
        Me.TextBoxMarketingSector.Location = New System.Drawing.Point(705, 456)
        Me.TextBoxMarketingSector.Name = "TextBoxMarketingSector"
        Me.TextBoxMarketingSector.ReadOnly = True
        Me.TextBoxMarketingSector.Size = New System.Drawing.Size(96, 20)
        Me.TextBoxMarketingSector.TabIndex = 96
        '
        'TextBoxPE
        '
        Me.TextBoxPE.Location = New System.Drawing.Point(854, 456)
        Me.TextBoxPE.Name = "TextBoxPE"
        Me.TextBoxPE.ReadOnly = True
        Me.TextBoxPE.Size = New System.Drawing.Size(83, 20)
        Me.TextBoxPE.TabIndex = 99
        '
        'TextBoxCountry
        '
        Me.TextBoxCountry.Location = New System.Drawing.Point(854, 430)
        Me.TextBoxCountry.Name = "TextBoxCountry"
        Me.TextBoxCountry.ReadOnly = True
        Me.TextBoxCountry.Size = New System.Drawing.Size(83, 20)
        Me.TextBoxCountry.TabIndex = 98
        '
        'TextBoxIndustry
        '
        Me.TextBoxIndustry.Location = New System.Drawing.Point(854, 403)
        Me.TextBoxIndustry.Name = "TextBoxIndustry"
        Me.TextBoxIndustry.ReadOnly = True
        Me.TextBoxIndustry.Size = New System.Drawing.Size(83, 20)
        Me.TextBoxIndustry.TabIndex = 97
        '
        'TextBoxVolume
        '
        Me.TextBoxVolume.Location = New System.Drawing.Point(1016, 456)
        Me.TextBoxVolume.Name = "TextBoxVolume"
        Me.TextBoxVolume.ReadOnly = True
        Me.TextBoxVolume.Size = New System.Drawing.Size(83, 20)
        Me.TextBoxVolume.TabIndex = 102
        '
        'TextBoxChange
        '
        Me.TextBoxChange.Location = New System.Drawing.Point(1016, 431)
        Me.TextBoxChange.Name = "TextBoxChange"
        Me.TextBoxChange.ReadOnly = True
        Me.TextBoxChange.Size = New System.Drawing.Size(83, 20)
        Me.TextBoxChange.TabIndex = 101
        '
        'TextBoxPrice
        '
        Me.TextBoxPrice.Location = New System.Drawing.Point(1016, 404)
        Me.TextBoxPrice.Name = "TextBoxPrice"
        Me.TextBoxPrice.ReadOnly = True
        Me.TextBoxPrice.Size = New System.Drawing.Size(83, 20)
        Me.TextBoxPrice.TabIndex = 100
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Purple
        Me.Label17.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label17.Location = New System.Drawing.Point(788, 385)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(62, 13)
        Me.Label17.TabIndex = 103
        Me.Label17.Text = "Mkt cap (B)"
        '
        'TextBoxMktCap
        '
        Me.TextBoxMktCap.Location = New System.Drawing.Point(854, 378)
        Me.TextBoxMktCap.Name = "TextBoxMktCap"
        Me.TextBoxMktCap.ReadOnly = True
        Me.TextBoxMktCap.Size = New System.Drawing.Size(83, 20)
        Me.TextBoxMktCap.TabIndex = 104
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Purple
        Me.TextBox1.Location = New System.Drawing.Point(609, 367)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(499, 120)
        Me.TextBox1.TabIndex = 105
        '
        'quitButton
        '
        Me.quitButton.BackColor = System.Drawing.Color.Red
        Me.quitButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.quitButton.Location = New System.Drawing.Point(1273, 449)
        Me.quitButton.Name = "quitButton"
        Me.quitButton.Size = New System.Drawing.Size(60, 30)
        Me.quitButton.TabIndex = 106
        Me.quitButton.Text = "Quit "
        Me.quitButton.UseVisualStyleBackColor = False
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Indigo
        Me.TextBox2.Location = New System.Drawing.Point(15, 372)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(95, 23)
        Me.TextBox2.TabIndex = 107
        '
        'ListBox1
        '
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.ColumnWidth = 50
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(1169, 112)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ListBox1.Size = New System.Drawing.Size(114, 260)
        Me.ListBox1.TabIndex = 108
        '
        'Timer1
        '
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Purple
        Me.Label11.Location = New System.Drawing.Point(1170, 72)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(198, 15)
        Me.Label11.TabIndex = 110
        Me.Label11.Text = "size of companies MKt cap(B)"
        '
        'ListBox2
        '
        Me.ListBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox2.ColumnWidth = 50
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(1289, 112)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ListBox2.Size = New System.Drawing.Size(70, 260)
        Me.ListBox2.TabIndex = 111
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Purple
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label12.Location = New System.Drawing.Point(1170, 96)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(80, 13)
        Me.Label12.TabIndex = 112
        Me.Label12.Text = "Company name"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Purple
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label13.Location = New System.Drawing.Point(1286, 96)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(62, 13)
        Me.Label13.TabIndex = 113
        Me.Label13.Text = "Mkt cap (B)"
        '
        'ButtonClear
        '
        Me.ButtonClear.Location = New System.Drawing.Point(450, 448)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(121, 21)
        Me.ButtonClear.TabIndex = 114
        Me.ButtonClear.Text = "Refresh Filters"
        Me.ButtonClear.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Purple
        Me.Label1.Location = New System.Drawing.Point(140, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(902, 13)
        Me.Label1.TabIndex = 115
        Me.Label1.Text = "Welcome to the virtual stock exchange, use the filters below/spotlight search to " &
    "find your required record listing you would want to modify. 'Select Sell/Remove'" &
    " or 'Buy listing'  to carry this out."
        '
        'buyListing
        '
        Me.buyListing.BackColor = System.Drawing.Color.Purple
        Me.buyListing.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buyListing.ForeColor = System.Drawing.SystemColors.Control
        Me.buyListing.Location = New System.Drawing.Point(1109, 436)
        Me.buyListing.Name = "buyListing"
        Me.buyListing.Size = New System.Drawing.Size(121, 51)
        Me.buyListing.TabIndex = 116
        Me.buyListing.Text = "Buy listing"
        Me.buyListing.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1373, 491)
        Me.Controls.Add(Me.buyListing)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ButtonClear)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.quitButton)
        Me.Controls.Add(Me.TextBoxMktCap)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.TextBoxVolume)
        Me.Controls.Add(Me.TextBoxChange)
        Me.Controls.Add(Me.TextBoxPrice)
        Me.Controls.Add(Me.TextBoxPE)
        Me.Controls.Add(Me.TextBoxCountry)
        Me.Controls.Add(Me.TextBoxIndustry)
        Me.Controls.Add(Me.TextBoxMarketingSector)
        Me.Controls.Add(Me.TextBoxCompanyName)
        Me.Controls.Add(Me.TextBoxSymbol)
        Me.Controls.Add(Me.TextBoxID)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.spotlightSearch)
        Me.Controls.Add(Me.searchBox)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnDisplayData)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.helpButton2)
        Me.Controls.Add(Me.ComboBox9)
        Me.Controls.Add(Me.ComboBox8)
        Me.Controls.Add(Me.PEcomboBox)
        Me.Controls.Add(Me.ComboBox5)
        Me.Controls.Add(Me.ComboBox4)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.buySellButton)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Name = "Form2"
        Me.Text = "virtual exchange"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StockExchangeDataSet1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StockExchangeBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StockExchangeDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StockExchangeDataSet1BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents buySellButton As Button
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents PEcomboBox As ComboBox
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents helpButton2 As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label14 As Label
    Friend WithEvents btnDisplayData As Button
    Friend WithEvents StockExchangeDataSet1BindingSource As BindingSource
    Friend WithEvents StockExchangeBindingSource2 As BindingSource
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents StockExchangeDataSet1BindingSource1 As BindingSource
    Friend WithEvents StockExchangeDataSet1 As stockExchangeDataSet1
    Friend WithEvents searchBox As TextBox
    Friend WithEvents spotlightSearch As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents TextBoxID As TextBox
    Friend WithEvents TextBoxSymbol As TextBox
    Friend WithEvents TextBoxCompanyName As TextBox
    Friend WithEvents TextBoxMarketingSector As TextBox
    Friend WithEvents TextBoxPE As TextBox
    Friend WithEvents TextBoxCountry As TextBox
    Friend WithEvents TextBoxIndustry As TextBox
    Friend WithEvents TextBoxVolume As TextBox
    Friend WithEvents TextBoxChange As TextBox
    Friend WithEvents TextBoxPrice As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents TextBoxMktCap As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents quitButton As Button
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label11 As Label
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents ButtonClear As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents buyListing As Button
End Class
