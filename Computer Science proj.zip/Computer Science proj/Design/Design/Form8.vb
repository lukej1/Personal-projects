﻿'Importing mysql data in order for manipulation of data.
Imports MySql.Data.MySqlClient

Public Class Form8 'Remove a listing.
    'Declaring all key MySql variables used to manipulate data.
    Dim connection As New MySqlConnection("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
    Dim COMMAND As MySqlCommand
    Dim READER As MySqlDataReader

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form4.Show() 'Takes the client back to the selection page.
        Me.Hide() 'Hides this form.

    End Sub

    Private Sub Form8_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True 'Enables the state of the timer to True, allowing it to tick.
    End Sub

    Private Sub LabelTime_Click(sender As Object, e As EventArgs) Handles Timer1.Tick
        LabelTime.Text = Date.Now.ToString("dd-MM-yyyy  hh:mm:ss") 'Format for date and time fetched and displayed within the program.
    End Sub

    Private Sub removeButton_Click(sender As Object, e As EventArgs) Handles removeButton.Click
        'Delete a record query from database
        Try
            connection.Open() 'Opening the connection to the mysql database.
            Dim Query As String
            'Deletes an entry entry from the database where the remove button acts as a validation for the 'symbol' column, which equates to
            'symbolDelete.text'.
            Query = "Delete from stockexchange.virtualexchange where symbol='" & symbolDelete.Text & "'"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader 'READER delcared as the command in order to execute.
            Form6.Show() 'Shows the 'success' application, identifying the query has been executed with no errors.
            Me.Hide() 'Hides the 'Remove a listing form.
            connection.Close() 'Closes the connection as it's not needed.

        Catch ex As MySqlException
            Form7.Show() 'If an error occurs, form7 being the 'error' page will be presented to the client.
            Me.Hide() 'Hides the 'remove listing' application.
        Finally
            connection.Dispose() 'Closes any connections if any are still open influencing performance.
        End Try
    End Sub

    Private Sub helpRemove_Click(sender As Object, e As EventArgs) Handles helpRemove.Click
        'This help message states what the client must do in order to remove a listing.
        MessageBox.Show("Simply enter the 'symbol' of the listing you wish to remove from the virtual exchange")
    End Sub
End Class