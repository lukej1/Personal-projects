﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormBuy
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormBuy))
        Dim ChartArea3 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend3 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.volumeUpdate = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.analytics = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.purchaseShares = New System.Windows.Forms.Button()
        Me.priceBuy = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.loadChart = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.LabelTime = New System.Windows.Forms.Label()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.idPurchase = New System.Windows.Forms.TextBox()
        Me.symbolPurchase = New System.Windows.Forms.TextBox()
        Me.namePurchase = New System.Windows.Forms.TextBox()
        Me.sectorPurchase = New System.Windows.Forms.TextBox()
        Me.industryPurchase = New System.Windows.Forms.TextBox()
        Me.countryPurchase = New System.Windows.Forms.TextBox()
        Me.pePurchase = New System.Windows.Forms.TextBox()
        Me.pricePurchase = New System.Windows.Forms.TextBox()
        Me.changePurchase = New System.Windows.Forms.TextBox()
        Me.volumePurchase = New System.Windows.Forms.TextBox()
        Me.MKtcapPurchase = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.quantityBuy = New System.Windows.Forms.TextBox()
        Me.IDlabel = New System.Windows.Forms.Label()
        Me.verifyID = New System.Windows.Forms.TextBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.exitButton = New System.Windows.Forms.Button()
        Me.calculation = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ListBoxPredict = New System.Windows.Forms.ListBox()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(33, 156)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(20, 13)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "ID"
        '
        'volumeUpdate
        '
        Me.volumeUpdate.AutoSize = True
        Me.volumeUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.volumeUpdate.Location = New System.Drawing.Point(694, 157)
        Me.volumeUpdate.Name = "volumeUpdate"
        Me.volumeUpdate.Size = New System.Drawing.Size(48, 13)
        Me.volumeUpdate.TabIndex = 31
        Me.volumeUpdate.Text = "Volume"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(640, 156)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(50, 13)
        Me.Label8.TabIndex = 30
        Me.Label8.Text = "Change"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(587, 156)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 13)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Price"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(472, 156)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Country"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(371, 156)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Industry"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(539, 156)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "P/E"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(247, 156)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 13)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Marketing sector"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(122, 156)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Company name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(68, 156)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Symbol"
        '
        'analytics
        '
        Me.analytics.BackColor = System.Drawing.Color.Green
        Me.analytics.ForeColor = System.Drawing.SystemColors.Control
        Me.analytics.Location = New System.Drawing.Point(393, 276)
        Me.analytics.Name = "analytics"
        Me.analytics.Size = New System.Drawing.Size(74, 51)
        Me.analytics.TabIndex = 33
        Me.analytics.Text = "display prediction"
        Me.analytics.UseVisualStyleBackColor = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(67, 272)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(100, 13)
        Me.Label13.TabIndex = 39
        Me.Label13.Text = "quantity demanded "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(67, 295)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(45, 13)
        Me.Label14.TabIndex = 47
        Me.Label14.Text = "price (£)"
        '
        'purchaseShares
        '
        Me.purchaseShares.BackColor = System.Drawing.Color.Crimson
        Me.purchaseShares.ForeColor = System.Drawing.SystemColors.Control
        Me.purchaseShares.Location = New System.Drawing.Point(142, 355)
        Me.purchaseShares.Name = "purchaseShares"
        Me.purchaseShares.Size = New System.Drawing.Size(85, 26)
        Me.purchaseShares.TabIndex = 48
        Me.purchaseShares.Text = "purchase"
        Me.purchaseShares.UseVisualStyleBackColor = False
        '
        'priceBuy
        '
        Me.priceBuy.Location = New System.Drawing.Point(217, 292)
        Me.priceBuy.Name = "priceBuy"
        Me.priceBuy.Size = New System.Drawing.Size(100, 20)
        Me.priceBuy.TabIndex = 49
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(508, 232)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(340, 175)
        Me.TextBox6.TabIndex = 50
        '
        'loadChart
        '
        Me.loadChart.BackColor = System.Drawing.Color.Indigo
        Me.loadChart.ForeColor = System.Drawing.SystemColors.Control
        Me.loadChart.Location = New System.Drawing.Point(510, 304)
        Me.loadChart.Name = "loadChart"
        Me.loadChart.Size = New System.Drawing.Size(85, 22)
        Me.loadChart.TabIndex = 52
        Me.loadChart.Text = "Chart"
        Me.loadChart.UseVisualStyleBackColor = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(185, 41)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(0, 13)
        Me.Label16.TabIndex = 56
        '
        'LabelTime
        '
        Me.LabelTime.AutoSize = True
        Me.LabelTime.Location = New System.Drawing.Point(590, 73)
        Me.LabelTime.Name = "LabelTime"
        Me.LabelTime.Size = New System.Drawing.Size(75, 13)
        Me.LabelTime.TabIndex = 73
        Me.LabelTime.Text = "local date,time"
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.Purple
        Me.Button14.ForeColor = System.Drawing.SystemColors.Control
        Me.Button14.Location = New System.Drawing.Point(3, 5)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(39, 33)
        Me.Button14.TabIndex = 75
        Me.Button14.Text = "help"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Purple
        Me.Button5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button5.Location = New System.Drawing.Point(26, 96)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(181, 43)
        Me.Button5.TabIndex = 76
        Me.Button5.Text = "buy shares"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Purple
        Me.Button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button4.Location = New System.Drawing.Point(130, 387)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(111, 31)
        Me.Button4.TabIndex = 77
        Me.Button4.Text = "back"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Indigo
        Me.Button7.ForeColor = System.Drawing.SystemColors.Control
        Me.Button7.Location = New System.Drawing.Point(393, 329)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(74, 33)
        Me.Button7.TabIndex = 78
        Me.Button7.Text = "how to use"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Purple
        Me.Label18.Location = New System.Drawing.Point(135, 13)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(403, 25)
        Me.Label18.TabIndex = 79
        Me.Label18.Text = "Virtual stock exchange purchase shares "
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(43, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 81)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 80
        Me.PictureBox1.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(750, 157)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(66, 13)
        Me.Label19.TabIndex = 81
        Me.Label19.Text = "MKtcap(B)"
        '
        'idPurchase
        '
        Me.idPurchase.BackColor = System.Drawing.SystemColors.Control
        Me.idPurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.idPurchase.Location = New System.Drawing.Point(35, 174)
        Me.idPurchase.Name = "idPurchase"
        Me.idPurchase.Size = New System.Drawing.Size(27, 13)
        Me.idPurchase.TabIndex = 82
        '
        'symbolPurchase
        '
        Me.symbolPurchase.BackColor = System.Drawing.SystemColors.Control
        Me.symbolPurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.symbolPurchase.Location = New System.Drawing.Point(70, 174)
        Me.symbolPurchase.Name = "symbolPurchase"
        Me.symbolPurchase.Size = New System.Drawing.Size(43, 13)
        Me.symbolPurchase.TabIndex = 83
        '
        'namePurchase
        '
        Me.namePurchase.BackColor = System.Drawing.SystemColors.Control
        Me.namePurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.namePurchase.Location = New System.Drawing.Point(124, 174)
        Me.namePurchase.Name = "namePurchase"
        Me.namePurchase.Size = New System.Drawing.Size(114, 13)
        Me.namePurchase.TabIndex = 84
        '
        'sectorPurchase
        '
        Me.sectorPurchase.BackColor = System.Drawing.SystemColors.Control
        Me.sectorPurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.sectorPurchase.Location = New System.Drawing.Point(250, 174)
        Me.sectorPurchase.Name = "sectorPurchase"
        Me.sectorPurchase.Size = New System.Drawing.Size(111, 13)
        Me.sectorPurchase.TabIndex = 85
        '
        'industryPurchase
        '
        Me.industryPurchase.BackColor = System.Drawing.SystemColors.Control
        Me.industryPurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.industryPurchase.Location = New System.Drawing.Point(373, 174)
        Me.industryPurchase.Name = "industryPurchase"
        Me.industryPurchase.Size = New System.Drawing.Size(94, 13)
        Me.industryPurchase.TabIndex = 86
        '
        'countryPurchase
        '
        Me.countryPurchase.BackColor = System.Drawing.SystemColors.Control
        Me.countryPurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.countryPurchase.Location = New System.Drawing.Point(473, 174)
        Me.countryPurchase.Name = "countryPurchase"
        Me.countryPurchase.Size = New System.Drawing.Size(55, 13)
        Me.countryPurchase.TabIndex = 87
        '
        'pePurchase
        '
        Me.pePurchase.BackColor = System.Drawing.SystemColors.Control
        Me.pePurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.pePurchase.Location = New System.Drawing.Point(541, 174)
        Me.pePurchase.Name = "pePurchase"
        Me.pePurchase.Size = New System.Drawing.Size(43, 13)
        Me.pePurchase.TabIndex = 88
        '
        'pricePurchase
        '
        Me.pricePurchase.BackColor = System.Drawing.SystemColors.Control
        Me.pricePurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.pricePurchase.Location = New System.Drawing.Point(589, 174)
        Me.pricePurchase.Name = "pricePurchase"
        Me.pricePurchase.Size = New System.Drawing.Size(43, 13)
        Me.pricePurchase.TabIndex = 89
        '
        'changePurchase
        '
        Me.changePurchase.BackColor = System.Drawing.SystemColors.Control
        Me.changePurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.changePurchase.Location = New System.Drawing.Point(643, 174)
        Me.changePurchase.Name = "changePurchase"
        Me.changePurchase.Size = New System.Drawing.Size(45, 13)
        Me.changePurchase.TabIndex = 90
        '
        'volumePurchase
        '
        Me.volumePurchase.BackColor = System.Drawing.SystemColors.Control
        Me.volumePurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.volumePurchase.Location = New System.Drawing.Point(695, 174)
        Me.volumePurchase.Name = "volumePurchase"
        Me.volumePurchase.Size = New System.Drawing.Size(59, 13)
        Me.volumePurchase.TabIndex = 91
        '
        'MKtcapPurchase
        '
        Me.MKtcapPurchase.BackColor = System.Drawing.SystemColors.Control
        Me.MKtcapPurchase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MKtcapPurchase.Location = New System.Drawing.Point(753, 174)
        Me.MKtcapPurchase.Name = "MKtcapPurchase"
        Me.MKtcapPurchase.Size = New System.Drawing.Size(71, 13)
        Me.MKtcapPurchase.TabIndex = 92
        '
        'Timer1
        '
        '
        'quantityBuy
        '
        Me.quantityBuy.Location = New System.Drawing.Point(217, 268)
        Me.quantityBuy.Name = "quantityBuy"
        Me.quantityBuy.Size = New System.Drawing.Size(100, 20)
        Me.quantityBuy.TabIndex = 93
        '
        'IDlabel
        '
        Me.IDlabel.AutoSize = True
        Me.IDlabel.Location = New System.Drawing.Point(67, 246)
        Me.IDlabel.Name = "IDlabel"
        Me.IDlabel.Size = New System.Drawing.Size(75, 13)
        Me.IDlabel.TabIndex = 94
        Me.IDlabel.Text = "verify listing ID"
        '
        'verifyID
        '
        Me.verifyID.Location = New System.Drawing.Point(217, 243)
        Me.verifyID.Name = "verifyID"
        Me.verifyID.Size = New System.Drawing.Size(100, 20)
        Me.verifyID.TabIndex = 95
        '
        'Timer2
        '
        Me.Timer2.Interval = 10
        '
        'exitButton
        '
        Me.exitButton.BackColor = System.Drawing.Color.Purple
        Me.exitButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.exitButton.Location = New System.Drawing.Point(393, 368)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(74, 31)
        Me.exitButton.TabIndex = 98
        Me.exitButton.Text = "walk out"
        Me.exitButton.UseVisualStyleBackColor = False
        '
        'calculation
        '
        Me.calculation.AutoSize = True
        Me.calculation.Location = New System.Drawing.Point(575, 216)
        Me.calculation.Name = "calculation"
        Me.calculation.Size = New System.Drawing.Size(58, 13)
        Me.calculation.TabIndex = 99
        Me.calculation.Text = "calculation"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Blue
        Me.Label9.Location = New System.Drawing.Point(523, 216)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(51, 13)
        Me.Label9.TabIndex = 100
        Me.Label9.Text = "analytics:"
        '
        'ListBoxPredict
        '
        Me.ListBoxPredict.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBoxPredict.FormattingEnabled = True
        Me.ListBoxPredict.Location = New System.Drawing.Point(528, 242)
        Me.ListBoxPredict.MultiColumn = True
        Me.ListBoxPredict.Name = "ListBoxPredict"
        Me.ListBoxPredict.Size = New System.Drawing.Size(315, 39)
        Me.ListBoxPredict.TabIndex = 101
        '
        'Chart1
        '
        ChartArea3.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea3)
        Legend3.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend3)
        Me.Chart1.Location = New System.Drawing.Point(596, 288)
        Me.Chart1.Name = "Chart1"
        Series3.ChartArea = "ChartArea1"
        Series3.Legend = "Legend1"
        Series3.Name = "company analytics"
        Me.Chart1.Series.Add(Series3)
        Me.Chart1.Size = New System.Drawing.Size(251, 117)
        Me.Chart1.TabIndex = 102
        Me.Chart1.Text = "Chart1"
        '
        'FormBuy
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(853, 425)
        Me.Controls.Add(Me.Chart1)
        Me.Controls.Add(Me.ListBoxPredict)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.calculation)
        Me.Controls.Add(Me.exitButton)
        Me.Controls.Add(Me.verifyID)
        Me.Controls.Add(Me.IDlabel)
        Me.Controls.Add(Me.quantityBuy)
        Me.Controls.Add(Me.MKtcapPurchase)
        Me.Controls.Add(Me.volumePurchase)
        Me.Controls.Add(Me.changePurchase)
        Me.Controls.Add(Me.pricePurchase)
        Me.Controls.Add(Me.pePurchase)
        Me.Controls.Add(Me.countryPurchase)
        Me.Controls.Add(Me.industryPurchase)
        Me.Controls.Add(Me.sectorPurchase)
        Me.Controls.Add(Me.namePurchase)
        Me.Controls.Add(Me.symbolPurchase)
        Me.Controls.Add(Me.idPurchase)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.LabelTime)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.loadChart)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.priceBuy)
        Me.Controls.Add(Me.purchaseShares)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.analytics)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.volumeUpdate)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormBuy"
        Me.Text = "Form3"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label10 As Label
    Friend WithEvents volumeUpdate As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents analytics As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents purchaseShares As Button
    Friend WithEvents priceBuy As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents loadChart As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents LabelTime As Label
    Friend WithEvents Button14 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Label18 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label19 As Label
    Friend WithEvents idPurchase As TextBox
    Friend WithEvents symbolPurchase As TextBox
    Friend WithEvents namePurchase As TextBox
    Friend WithEvents sectorPurchase As TextBox
    Friend WithEvents industryPurchase As TextBox
    Friend WithEvents countryPurchase As TextBox
    Friend WithEvents pePurchase As TextBox
    Friend WithEvents pricePurchase As TextBox
    Friend WithEvents changePurchase As TextBox
    Friend WithEvents volumePurchase As TextBox
    Friend WithEvents MKtcapPurchase As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents quantityBuy As TextBox
    Friend WithEvents IDlabel As Label
    Friend WithEvents verifyID As TextBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents exitButton As Button
    Friend WithEvents calculation As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents ListBoxPredict As ListBox
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
End Class
