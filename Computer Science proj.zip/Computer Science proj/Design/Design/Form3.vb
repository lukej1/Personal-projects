﻿'Importing mysql data in order for manipulation of data.
Imports MySql.Data.MySqlClient

Public Class FormBuy 'Buy shares
    'Declaring all key MySql variables used to manipulate data.
    'Connection states the type and string for the connection to the MySQL database.
    Dim connection As New MySqlConnection("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
    'Both reader and command used alongside 'query' for the retrieval of data.
    Dim COMMAND As MySqlCommand
    Dim READER As MySqlDataReader


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form2.Show() 'Closes form2
        Me.Hide() 'Hides current form from user.

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        LabelTime.Text = Date.Now.ToString("dd-MM-yyyy  hh:mm:ss") 'Date and time delcared as string format using date.now to get current values.
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Timer1.Enabled = True 'Initiates the status of the timer allowing multiple functions to execute when TRUE
        Timer2.Enabled = True
    End Sub

    Private Sub purchaseShares_Click(sender As Object, e As EventArgs) Handles purchaseShares.Click
        Try
            connection.Open()
            Dim Query As String

            'This query is responsible for updating database values under the 'volume' column. The purpose of using 'CInt' allows the label.text datatype to be 
            'Converted to the correct type for when the database side is updating columns. The where clause is a form of validation for the updating of shares
            'Because it will update volume only when the ID is entered and also compared to the database type.
            Query = "update stockexchange.virtualexchange set volume = (volume-" & CInt(quantityBuy.Text) & ") " & "where ID =" & CInt(verifyID.Text) & ""
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader
            Form6.Show() 'Shows the success page, meaning the command was executed correctly
            Me.Hide() 'Hides this form allowing the client to return to exchange on 'success' page.
            connection.Close()

        Catch ex As MySqlException

            MessageBox.Show(ex.Message)

            Form7.Show() 'This will display an error message if there is an error
            Me.Hide() 'Hides current form.
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        'The contents of the code being in timer function is so that entries dont need a 'click' event, increasing the functionality.
        priceBuy.Text = Val(quantityBuy.Text) * Val(pricePurchase.Text)
        'This is used in order to display the total price of shares the client wishes to buy.
        calculation.Text = Val(pePurchase.Text) * Val(changePurchase.Text)
        'This is what is used for the analytics part of the program. It gives the client a decimal value and
        'Is later used for presenting a graph and a prediction.



        'If statement to convert the colour of presenting 'calculation' to the required condition. For example the value being less than 0 will
        'give the colour red. This is done by using local command 'forecolor=colour.'
        If Val(calculation.Text) < 0 Then
            calculation.ForeColor = Color.Red
        Else
            calculation.ForeColor = Color.Green
        End If
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        'Help message to assist the client with this part of the program.
        MessageBox.Show("This is where you can buy shares from a listing of your choice." & vbNewLine & vbNewLine & "If you dont feel confident in the listing you selected, press the 'display prediction' button where we can identify if the shares are worth investing." & vbNewLine & vbNewLine & " If you feel like you do not want this particular listing, simply press the 'back' button and select another one from the filter section of the exchange")
    End Sub

    Private Sub analytics_Click(sender As Object, e As EventArgs) Handles analytics.Click

        'If statement to output prediction to listBox. If the value of 'calculation' is <0.5 then the program will output that the listing 
        'is not worth investing in. Elseif the program will advise the client to buy into the listing.
        If Val(calculation.Text) < 0.5 Then
            ListBoxPredict.Items.Add("This listing is not worth" & vbNewLine & " investing in. percentage change = " & changePurchase.Text & "%")
        ElseIf Val(calculation.Text) > 0.5 Then
            ListBoxPredict.Items.Add("This listing is worth investing in. percentage change = " & changePurchase.Text & "%")

        End If
    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Close() 'Closes the form.

    End Sub

    Private Sub loadChart_Click(sender As Object, e As EventArgs) Handles loadChart.Click
        Try
            connection.Open()
            Dim Query As String

            'This query will fetch the contents of an instance of companyNamw where the second condition 'where' equals the value of 'ID' in the 'idPurchase'
            'Text format.
            Query = "SELECT companyName from stockexchange.virtualexchange where ID =" & CInt(idPurchase.Text) & "" 'Converts the format to an integer for the database.
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader

            While READER.Read 'The program will execute the following command whilst the reader.read is executed.
                Chart1.Series("company analytics").Points.AddXY(READER.GetString("companyName"), Val(calculation.Text))
                'Chart1 as a series of datatypes from database and form. '.series' refers to the name of chart and will point to the XY values being 'companyName' and 
                'calculation.text'
            End While
            connection.Close()

        Catch ex As MySqlException

            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        'An additional messagebox referrs to the help/assistance the client may need in order to understand when using the analytics component part of the program.
        MessageBox.Show("By pressing the 'display prediction' will allow you to decide wether you would like to purchase the listing or not based on the value calculated.

You will be further be given the ability to identfiy the company name and the calculated value within a chart format. 

By pressing the 'walk out' button will close the page.")
    End Sub
End Class