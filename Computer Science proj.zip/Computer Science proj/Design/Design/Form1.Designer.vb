﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.submit = New System.Windows.Forms.Button()
        Me.TextBoxuserName = New System.Windows.Forms.TextBox()
        Me.TextBoxbankOrganisation = New System.Windows.Forms.TextBox()
        Me.TextBoxsecurityKey = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.StockExchangeDataSet1 = New Design.stockExchangeDataSet1()
        Me.StockExchangeDataSet1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StockExchangeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StockExchangeTableAdapter = New Design.stockExchangeDataSetTableAdapters.stockExchangeTableAdapter()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StockExchangeDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StockExchangeDataSet1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StockExchangeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'submit
        '
        Me.submit.BackColor = System.Drawing.Color.Green
        Me.submit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.submit.Location = New System.Drawing.Point(215, 226)
        Me.submit.Name = "submit"
        Me.submit.Size = New System.Drawing.Size(60, 30)
        Me.submit.TabIndex = 0
        Me.submit.Text = "Submit"
        Me.submit.UseVisualStyleBackColor = False
        '
        'TextBoxuserName
        '
        Me.TextBoxuserName.Location = New System.Drawing.Point(169, 148)
        Me.TextBoxuserName.Name = "TextBoxuserName"
        Me.TextBoxuserName.Size = New System.Drawing.Size(163, 20)
        Me.TextBoxuserName.TabIndex = 1
        '
        'TextBoxbankOrganisation
        '
        Me.TextBoxbankOrganisation.Location = New System.Drawing.Point(169, 174)
        Me.TextBoxbankOrganisation.Name = "TextBoxbankOrganisation"
        Me.TextBoxbankOrganisation.Size = New System.Drawing.Size(163, 20)
        Me.TextBoxbankOrganisation.TabIndex = 2
        '
        'TextBoxsecurityKey
        '
        Me.TextBoxsecurityKey.Location = New System.Drawing.Point(169, 200)
        Me.TextBoxsecurityKey.Name = "TextBoxsecurityKey"
        Me.TextBoxsecurityKey.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TextBoxsecurityKey.Size = New System.Drawing.Size(163, 20)
        Me.TextBoxsecurityKey.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 155)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Username"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 181)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Bank Organisation"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 207)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Security Key"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Purple
        Me.Label4.Location = New System.Drawing.Point(138, 90)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(228, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Welcome to the virtual stock exchange sign in,"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Red
        Me.Button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.Location = New System.Drawing.Point(327, 273)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(60, 30)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "Quit "
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Purple
        Me.Button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button3.Location = New System.Drawing.Point(12, 273)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(60, 30)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "Refresh"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Purple
        Me.Label6.Location = New System.Drawing.Point(187, 37)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(132, 25)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Enter details"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Purple
        Me.Label8.Location = New System.Drawing.Point(126, 103)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(246, 13)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = " please enter your details for access to our systems"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(2, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(93, 87)
        Me.PictureBox1.TabIndex = 14
        Me.PictureBox1.TabStop = False
        '
        'StockExchangeDataSet1
        '
        Me.StockExchangeDataSet1.DataSetName = "stockExchangeDataSet1"
        Me.StockExchangeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StockExchangeDataSet1BindingSource
        '
        Me.StockExchangeDataSet1BindingSource.DataSource = Me.StockExchangeDataSet1
        Me.StockExchangeDataSet1BindingSource.Position = 0
        '
        'StockExchangeTableAdapter
        '
        Me.StockExchangeTableAdapter.ClearBeforeFill = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(399, 315)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBoxsecurityKey)
        Me.Controls.Add(Me.TextBoxbankOrganisation)
        Me.Controls.Add(Me.TextBoxuserName)
        Me.Controls.Add(Me.submit)
        Me.Name = "Form1"
        Me.Text = "Log in "
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StockExchangeDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StockExchangeDataSet1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StockExchangeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents submit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents StockExchangeDataSet1 As stockExchangeDataSet1
    Friend WithEvents StockExchangeDataSet1BindingSource As BindingSource
    Friend WithEvents StockExchangeBindingSource As BindingSource
    Friend WithEvents StockExchangeTableAdapter As stockExchangeDataSetTableAdapters.stockExchangeTableAdapter
    Public WithEvents TextBoxuserName As TextBox
    Public WithEvents TextBoxbankOrganisation As TextBox
    Public WithEvents TextBoxsecurityKey As TextBox
End Class
