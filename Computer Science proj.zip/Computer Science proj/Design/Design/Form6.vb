﻿Public Class Form6 'Success window
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form2.Show() 'Returns to the virtual exchange
        Me.Hide() 'Hides this form.
    End Sub
End Class