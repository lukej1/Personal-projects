﻿Public Class Form4
    'Selection page.
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles backButton.Click 'back'
        Form2.Show() 'Shows form2, being the main exchange.
        Me.Hide() 'Hides the selection page.

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        FormBuy.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles sellListing.Click 'Buy shares'
        Form5.Show() 'Shows the form.
        Me.Hide() 'Hides the selection page.
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles removeListing.Click 'remove listing'
        Form8.Show() 'Shows the form.
        Me.Hide() 'Hides the selection page.

    End Sub

    Private Sub helpButton4_Click(sender As Object, e As EventArgs) Handles helpButton4.Click
        'Help message presented to the user if they do not know the purpose of the selection page.
        MessageBox.Show("Making a selection will move you to the desired page, either Buy/Sell or remove a listing. To return to the exchange press 'back' ")
    End Sub
End Class