﻿Partial Class stockExchangeDataSet1
End Class

Namespace stockExchangeDataSet1TableAdapters

    Partial Public Class stockExchangeTableAdapter
    End Class
End Namespace
