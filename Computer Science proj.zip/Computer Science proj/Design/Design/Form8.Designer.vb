﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form8
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form8))
        Me.removeButton = New System.Windows.Forms.Button()
        Me.helpRemove = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.LabelTime = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.symbolDelete = New System.Windows.Forms.TextBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'removeButton
        '
        Me.removeButton.BackColor = System.Drawing.Color.Red
        Me.removeButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.removeButton.Location = New System.Drawing.Point(185, 170)
        Me.removeButton.Name = "removeButton"
        Me.removeButton.Size = New System.Drawing.Size(181, 38)
        Me.removeButton.TabIndex = 137
        Me.removeButton.Text = "remove"
        Me.removeButton.UseVisualStyleBackColor = False
        '
        'helpRemove
        '
        Me.helpRemove.BackColor = System.Drawing.Color.Purple
        Me.helpRemove.ForeColor = System.Drawing.SystemColors.Control
        Me.helpRemove.Location = New System.Drawing.Point(0, 1)
        Me.helpRemove.Name = "helpRemove"
        Me.helpRemove.Size = New System.Drawing.Size(39, 33)
        Me.helpRemove.TabIndex = 138
        Me.helpRemove.Text = "help"
        Me.helpRemove.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Purple
        Me.Button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button4.Location = New System.Drawing.Point(218, 292)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(111, 31)
        Me.Button4.TabIndex = 141
        Me.Button4.Text = "back"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(40, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 81)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 142
        Me.PictureBox1.TabStop = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Purple
        Me.Label18.Location = New System.Drawing.Point(134, 34)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(384, 25)
        Me.Label18.TabIndex = 143
        Me.Label18.Text = "virtual stock exchange remove a listing"
        '
        'LabelTime
        '
        Me.LabelTime.AutoSize = True
        Me.LabelTime.Location = New System.Drawing.Point(380, 69)
        Me.LabelTime.Name = "LabelTime"
        Me.LabelTime.Size = New System.Drawing.Size(75, 13)
        Me.LabelTime.TabIndex = 144
        Me.LabelTime.Text = "local date,time"
        '
        'Timer1
        '
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Purple
        Me.Label1.Location = New System.Drawing.Point(204, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 25)
        Me.Label1.TabIndex = 145
        Me.Label1.Text = "Remove listing"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(226, 147)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 146
        Me.Label4.Text = "Symbol"
        '
        'symbolDelete
        '
        Me.symbolDelete.Location = New System.Drawing.Point(284, 144)
        Me.symbolDelete.Name = "symbolDelete"
        Me.symbolDelete.Size = New System.Drawing.Size(56, 20)
        Me.symbolDelete.TabIndex = 147
        '
        'Form8
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(526, 335)
        Me.Controls.Add(Me.symbolDelete)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LabelTime)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.helpRemove)
        Me.Controls.Add(Me.removeButton)
        Me.Name = "Form8"
        Me.Text = "Form8"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents removeButton As Button
    Friend WithEvents helpRemove As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label18 As Label
    Friend WithEvents LabelTime As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents symbolDelete As TextBox
End Class
