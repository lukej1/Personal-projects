﻿'Importing mysql data in order for manipulation of data.
Imports MySql.Data.MySqlClient
Public Class Form2 'Virtual exchange
    'Declaring all key MySql variables used to manipulate data.
    Dim connection As New MySqlConnection("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
    Dim COMMAND As MySqlCommand
    Dim dataBaseDataSet As New DataTable
    Dim SDA As New MySqlDataAdapter



    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        FilterData("")
        'The timer command identifies within the main load event of the program to execute the timer property, displaying the 
        'Contents of the timer string format, displaying the time and date. 
        Timer1.Enabled = True
        'Declaring the connection as MySql in order for the database to be retreived under the dame class of connection.
        connection = New MySqlConnection
        'Stating the connection strings value for the connection to take place.
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        'Declaring the ability to read from database in order to retreive when using query.
        Dim READER As MySqlDataReader

        'Try Catch block stating what the program should execute, involving using Query to fetch the data from the database.
        Try
            'Opening the connection to mySQL database.
            connection.Open()
            'Declaring query as a string datatype that is read within workbench (sql) in order to fetch appropriate data.
            Dim Query As String
            'Selecting column names from database.table name.
            Query = "select distinct companyName from stockexchange.virtualexchange"
            'The value of Query and Connection are passed into command within Try block and uses this to send to the data
            'base stating what the purpose of the request COMMAND is, to provide query and the connection the data will be 
            'going to.
            COMMAND = New MySqlCommand(Query, connection)
            'This reads COMMAND and is responsible for the read of query.
            READER = COMMAND.ExecuteReader


            While READER.Read
                'Within the while loop, variable company name is declared and assigned its equivalent mySQL datatype and referrs to
                'the combo box the column name reffers to for the filter listing part of the program.
                Dim companyName = READER.GetString("companyName")
                ComboBox2.Items.Add(companyName)


            End While
            'Closes connection when While loop has been satisfied.
            connection.Close()
            'The Catch block is responsible for handling errors that may occur within the code. For example incorrect queries or an error
            'in the client input. This allows them to identify the program has encountered an error but wont execute as syntax error.
        Catch ex As Exception
            'Method of displaying seperate box, containing the error.s
            MessageBox.Show(ex.Message)

            'After the 'Try' block or the 'Catch', regardless, the program will execute the contents of 'Finally' before ending the loop.
        Finally
            'This is to stop the login table data retrieval if the connection is still open, reducing processing
            'time.
            connection.Dispose()
        End Try


        Try
            connection.Open()
            Dim Query As String
            Query = "select distinct marketSector from stockexchange.virtualexchange" 'Selecting a distinct value from the database eliminates duplicate fields being presented in the filter.
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader


            While READER.Read

                Dim marketSector = READER.GetString("marketSector") 'Declaring values of each combo box within the filter functionality of the program where the reader will act.
                ComboBox4.Items.Add(marketSector) 'Populating the values of each combo box within the filter functionality of the program.


            End While

            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try

        Try
            connection.Open()
            Dim Query As String
            Query = "select distinct industry from stockexchange.virtualexchange" 'Similar select statement to first type in order to populate combobox.
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader


            While READER.Read

                Dim industry = READER.GetString("industry")
                ComboBox3.Items.Add(industry)
            End While
            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message) 'Error messages allow the user to identify any issue there may be, interface/database.
        Finally
            connection.Dispose()
        End Try

        Try
            connection.Open()
            Dim Query As String
            Query = "select distinct country from stockexchange.virtualexchange" 'Similar select statement to first type in order to populate combobox.
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader


            While READER.Read

                Dim country = READER.GetString("country") 'Referencing 'country' in this format allows the reader to function, fetching this data.
                ComboBox8.Items.Add(country)
            End While

            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try



        Try
            connection.Open()
            Dim Query As String
            Query = "select distinct price£ from stockexchange.virtualexchange" 'Similar select statement to first type in order to populate combobox.
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader


            While READER.Read

                Dim price = READER.GetFloat("price£")
                ComboBox9.Items.Add(price)
            End While

            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try


        Try
            connection.Open()
            Dim Query As String
            Query = "select distinct PE from stockexchange.virtualexchange" 'Similar select statement to first type in order to populate combobox.
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader


            While READER.Read

                Dim priceEarnings = READER.GetFloat("PE")
                PEcomboBox.Items.Add(priceEarnings)
            End While

            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try

        Try
            connection.Open()
            Dim Query As String
            Query = "select distinct volume from stockexchange.virtualexchange" 'Similar select statement to first type in order to populate combobox.
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader


            While READER.Read

                Dim volume = READER.GetInt32("volume")
                ComboBox5.Items.Add(volume)
            End While

            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try


        Try
            connection.Open()
            Dim Query As String
            'This query selects both column names and will order them by MKtcapB in descending order.
            Query = "select companyName, MKtcapB from stockexchange.virtualexchange order by MKtcapB desc"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader
            'Declaring the values datatype the program will be populating the list boxes with.
            Dim companyName As String 'datatype from database 
            Dim MKtcapB As Decimal
            While READER.Read
                companyName = READER.GetString("companyName") 'Reading all values 'companyName'
                MKtcapB = READER.GetDecimal("MKtcapB") 'Reading all values 'company name'
                ListBox1.Items.Add(companyName) 'Populating listbox1 to 'companyName'
                ListBox1.ForeColor = Color.Blue 'Declaring the colour of the contents of listbox1

                ListBox2.Items.Add(MKtcapB) 'Populating listbox2 to 'MKtcapB'
                ListBox2.ForeColor = Color.Blue 'Declaring the colour of the contents of listbox2.

            End While
            connection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try


    End Sub

    Public Sub FilterData(valueToSearch As String)


        Dim searchQuery As String = "SELECT * FROM virtualexchange WHERE CONCAT(ID, symbol, companyName, marketSector, industry, country, volume, MKtcapB,PE,price£,percentageChange) like '%" & searchBox.Text & "%'"
        'CONCAT means to Concatenate, meaning to group together one after the other in the query.
        'The wild card "%" is used within the like statement allowing multiple characters.
        Dim command As New MySqlCommand(searchQuery, connection)
        Dim adapter As New MySqlDataAdapter(command)
        'The new instance of DataTable 'table' will be used as the secondary source of the grid but only under the filter.
        Dim table As New DataTable()


        adapter.Fill(table) 'Fills the table with the new entry from the FilterData selection. Replacing the conents with clients desired search.


        DataGridView1.DataSource = table 'The instance of table is assigned to the datagrid allowing the filter to carry out.
        'Assigning the correct data field is important so the client can see the desired function from filters.
    End Sub




    Private Sub ComboBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox3.SelectedIndexChanged
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader
        Try
            connection.Open()
            Dim Query As String
            Query = "select * from stockexchange.virtualexchange where industry='" & ComboBox3.Text & "'"
            COMMAND = New MySqlCommand(Query, connection)

            READER = COMMAND.ExecuteReader
            While READER.Read

                TextBoxID.Text = READER.GetInt32("ID") 'Fetches the column name 'ID' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxSymbol.Text = READER.GetString("symbol") 'Fetches the column name 'symbol' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCompanyName.Text = READER.GetString("companyName") 'Fetches the column name 'companyName' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxMarketingSector.Text = READER.GetString("marketSector") 'Fetches the column name 'marketSector' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxIndustry.Text = READER.GetString("industry") 'Fetches the column name 'industry' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCountry.Text = READER.GetString("country") 'Fetches the column name 'country' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxPE.Text = READER.GetFloat("PE") 'Fetches the column name 'PE' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxPrice.Text = READER.GetFloat("price£") 'Fetches the column name 'price£' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxChange.Text = READER.GetFloat("percentageChange") 'Fetches the column name 'percentageChange' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxVolume.Text = READER.GetInt32("volume") 'Fetches the column name 'volume' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxMktCap.Text = READER.GetFloat("MKtcapB") 'Fetches the column name 'MKtcapB' from the database, using 'READER' in order to get the data type 'GetFloat'

            End While
            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs)
        Label15.Text = Date.Now.ToString("dd-MM-yyyy  hh:mm:ss") 'Format for date and time fetched and displayed within the program.
        Label15.Refresh()
    End Sub



    Private Sub btnDisplayData_Click(sender As Object, e As EventArgs) Handles btnDisplayData.Click
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim SDA As New MySqlDataAdapter ' The new instance of the adapter will be used when retreiving the data from the sql database.
        Dim dbDataSet As New DataTable
        Dim bSource As New BindingSource 'establishes a connection between the application and the database

        Try 'Try block used to determine what the code should execute 'try' first and if an error is encountered 
            connection.Open()
            Dim Query As String
            Query = "select * from stockexchange.virtualexchange" 'Selects all the data from the database.table allowing the program to populate this later on as a datagrid.
            COMMAND = New MySqlCommand(Query, connection)
            SDA.SelectCommand = COMMAND 'Selecting the appropriate COMMAND containing two data objects used for population of the table.
            SDA.Fill(dbDataSet) 'Populating the data table referencing the new instance of the adapter.
            bSource.DataSource = dbDataSet
            DataGridView1.DataSource = bSource 'Declaration to assign the source of data to the location of population for the data.
            SDA.Update(dbDataSet) 'When the client makes an alteration to the database, either dropping a listing/selling or buying shares, the adapter property will update the dataset.

            connection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub



    Private Sub Label15_Click(sender As Object, e As EventArgs) Handles Label15.Click
        Label15.Text = Date.Now.ToString("dd-MM-yyyy      hh:mm:ss") 'Date and time string format.
    End Sub

    Private Sub searchBox_TextChanged(sender As Object, e As EventArgs) Handles searchBox.TextChanged
        'Assigning the querydata from the 'FilterData' sub allowing the filter to be carried out.
        FilterData(searchBox.Text)
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader
        Try
            connection.Open()
            Dim Query As String
            'Select statement where the condition must match the value of ComboBox2.text equating to the column 'companyName'
            Query = "select * from stockexchange.virtualexchange where companyName='" & ComboBox2.Text & "'"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader
            While READER.Read
                'While loop, whilst the READER is reading the data within the DB, the program will excute the following code before the connection in the while loop ends.

                TextBoxID.Text = READER.GetInt32("ID") 'Fetches the column name 'ID' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxSymbol.Text = READER.GetString("symbol") 'Fetches the column name 'symbol' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCompanyName.Text = READER.GetString("companyName") 'Fetches the column name 'companyName' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxMarketingSector.Text = READER.GetString("marketSector") 'Fetches the column name 'marketSector' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxIndustry.Text = READER.GetString("industry") 'Fetches the column name 'industry' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCountry.Text = READER.GetString("country") 'Fetches the column name 'country' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxPE.Text = READER.GetFloat("PE") 'Fetches the column name 'PE' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxPrice.Text = READER.GetFloat("price£") 'Fetches the column name 'price£' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxChange.Text = READER.GetFloat("percentageChange") 'Fetches the column name 'percentageChange' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxVolume.Text = READER.GetInt32("volume") 'Fetches the column name 'volume' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxMktCap.Text = READER.GetFloat("MKtcapB") 'Fetches the column name 'MKtcapB' from the database, using 'READER' in order to get the data type 'GetFloat'

            End While

            connection.Close()  'Closing this allows security of the database, so multiple clients cannot modify multiple parts at once.

        Catch ex As Exception
            'An error may occur that the program may not be expecting. By using an 'ex.Message' allows the client to be 
            'prompted with this encounter. 
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub


    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox4.SelectedIndexChanged
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader
        Try
            connection.Open()
            Dim Query As String
            Query = "select * from stockexchange.virtualexchange where marketSector='" & ComboBox4.Text & "'"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader
            While READER.Read

                TextBoxID.Text = READER.GetInt32("ID") 'Fetches the column name 'ID' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxSymbol.Text = READER.GetString("symbol") 'Fetches the column name 'symbol' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCompanyName.Text = READER.GetString("companyName") 'Fetches the column name 'companyName' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxMarketingSector.Text = READER.GetString("marketSector") 'Fetches the column name 'marketSector' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxIndustry.Text = READER.GetString("industry") 'Fetches the column name 'industry' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCountry.Text = READER.GetString("country") 'Fetches the column name 'country' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxPE.Text = READER.GetFloat("PE") 'Fetches the column name 'PE' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxPrice.Text = READER.GetFloat("price£") 'Fetches the column name 'price£' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxChange.Text = READER.GetFloat("percentageChange") 'Fetches the column name 'percentageChange' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxVolume.Text = READER.GetInt32("volume") 'Fetches the column name 'volume' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxMktCap.Text = READER.GetFloat("MKtcapB") 'Fetches the column name 'MKtcapB' from the database, using 'READER' in order to get the data type 'GetFloat'

            End While
            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub ComboBox8_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox8.SelectedIndexChanged
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader
        Try
            connection.Open()
            Dim Query As String
            Query = "select * from stockexchange.virtualexchange where country='" & ComboBox8.Text & "'"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader
            While READER.Read
                TextBoxID.Text = READER.GetInt32("ID") 'Fetches the column name 'ID' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxSymbol.Text = READER.GetString("symbol") 'Fetches the column name 'symbol' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCompanyName.Text = READER.GetString("companyName") 'Fetches the column name 'companyName' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxMarketingSector.Text = READER.GetString("marketSector") 'Fetches the column name 'marketSector' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxIndustry.Text = READER.GetString("industry") 'Fetches the column name 'industry' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCountry.Text = READER.GetString("country") 'Fetches the column name 'country' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxPE.Text = READER.GetFloat("PE") 'Fetches the column name 'PE' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxPrice.Text = READER.GetFloat("price£") 'Fetches the column name 'price£' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxChange.Text = READER.GetFloat("percentageChange") 'Fetches the column name 'percentageChange' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxVolume.Text = READER.GetInt32("volume") 'Fetches the column name 'volume' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxMktCap.Text = READER.GetFloat("MKtcapB") 'Fetches the column name 'MKtcapB' from the database, using 'READER' in order to get the data type 'GetFloat'



            End While

            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub


    Private Sub ComboBox7_SelectedIndexChanged(sender As Object, e As EventArgs) Handles PEcomboBox.SelectedIndexChanged
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader

        Try
            connection.Open()
            Dim Query As String
            Query = "select * from stockexchange.virtualexchange where PE ='" & PEcomboBox.Text & "'"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader
            While READER.Read
                TextBoxID.Text = READER.GetInt32("ID") 'Fetches the column name 'ID' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxSymbol.Text = READER.GetString("symbol") 'Fetches the column name 'symbol' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCompanyName.Text = READER.GetString("companyName") 'Fetches the column name 'companyName' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxMarketingSector.Text = READER.GetString("marketSector") 'Fetches the column name 'marketSector' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxIndustry.Text = READER.GetString("industry") 'Fetches the column name 'industry' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCountry.Text = READER.GetString("country") 'Fetches the column name 'country' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxPE.Text = READER.GetFloat("PE") 'Fetches the column name 'PE' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxPrice.Text = READER.GetFloat("price£") 'Fetches the column name 'price£' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxChange.Text = READER.GetFloat("percentageChange") 'Fetches the column name 'percentageChange' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxVolume.Text = READER.GetInt32("volume") 'Fetches the column name 'volume' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxMktCap.Text = READER.GetFloat("MKtcapB") 'Fetches the column name 'MKtcapB' from the database, using 'READER' in order to get the data type 'GetFloat'




            End While

            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub ComboBox9_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox9.SelectedIndexChanged
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader
        Try
            connection.Open()
            Dim Query As String
            Query = "select * from stockexchange.virtualexchange where price£ ='" & ComboBox9.Text & "'"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader
            While READER.Read

                TextBoxID.Text = READER.GetInt32("ID") 'Fetches the column name 'ID' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxSymbol.Text = READER.GetString("symbol") 'Fetches the column name 'symbol' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCompanyName.Text = READER.GetString("companyName") 'Fetches the column name 'companyName' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxMarketingSector.Text = READER.GetString("marketSector") 'Fetches the column name 'marketSector' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxIndustry.Text = READER.GetString("industry") 'Fetches the column name 'industry' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCountry.Text = READER.GetString("country") 'Fetches the column name 'country' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxPE.Text = READER.GetFloat("PE") 'Fetches the column name 'PE' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxPrice.Text = READER.GetFloat("price£") 'Fetches the column name 'price£' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxChange.Text = READER.GetFloat("percentageChange") 'Fetches the column name 'percentageChange' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxVolume.Text = READER.GetInt32("volume") 'Fetches the column name 'volume' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxMktCap.Text = READER.GetFloat("MKtcapB") 'Fetches the column name 'MKtcapB' from the database, using 'READER' in order to get the data type 'GetFloat'


            End While

            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub ComboBox5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox5.SelectedIndexChanged
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader
        Try
            connection.Open()
            Dim Query As String
            'Select statement where the condition must match the value of ComboBox5.text equating to the column 'volume'
            Query = "select * from stockexchange.virtualexchange where volume ='" & ComboBox5.Text & "'"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader 'This is necessary within this component of the program to get the value of the mySQL datatype, in order to pass into a textbox.
            While READER.Read
                'While loop, whilst the READER is reading the data within the DB, the program will excute the following code before the connection in the while loop ends.

                TextBoxID.Text = READER.GetInt32("ID") 'Fetches the column name 'ID' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxSymbol.Text = READER.GetString("symbol") 'Fetches the column name 'symbol' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCompanyName.Text = READER.GetString("companyName") 'Fetches the column name 'companyName' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxMarketingSector.Text = READER.GetString("marketSector") 'Fetches the column name 'marketSector' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxIndustry.Text = READER.GetString("industry") 'Fetches the column name 'industry' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxCountry.Text = READER.GetString("country") 'Fetches the column name 'country' from the database, using 'READER' in order to get the data type 'GetString'
                TextBoxPE.Text = READER.GetFloat("PE") 'Fetches the column name 'PE' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxPrice.Text = READER.GetFloat("price£") 'Fetches the column name 'price£' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxChange.Text = READER.GetFloat("percentageChange") 'Fetches the column name 'percentageChange' from the database, using 'READER' in order to get the data type 'GetFloat'
                TextBoxVolume.Text = READER.GetInt32("volume") 'Fetches the column name 'volume' from the database, using 'READER' in order to get the data type 'GetInt32'
                TextBoxMktCap.Text = READER.GetFloat("MKtcapB") 'Fetches the column name 'MKtcapB' from the database, using 'READER' in order to get the data type 'GetFloat'


            End While
            'Closing this allows security of the database, so multiple clients cannot modify multiple parts at once.
            connection.Close()

        Catch ex As Exception
            'An error may occur that the program may not be expecting. By using an 'ex.Message' allows the client to be 
            'prompted with this encounter. 
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles quitButton.Click
        Close() 'Closes the virtual exchange
        connection.Close()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        'By using the 'FilterData' command within the datagrid allows the sub 'Filter data' to pass the command into a string
        'format "" allowing the input of column data on request.
        FilterData("")


    End Sub

    'Timer1.Tick' has been used rather than the 'click' property so it updates the label in intervals (seconds) rather than 
    'waiting for the user to click to update the values.
    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Declares the text property of 'label15' to the 'Date' property allowing the conversion type to a string containing the date and time 
        'properties on the local machine, displaying this to the user.
        Label15.Text = Date.Now.ToString("dd-MM-yyyy  hh:mm:ss")

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles spotlightSearch.Click

    End Sub

    Private Sub searchData_Click(sender As Object, e As EventArgs)
        ' FilterData(searchBox.Text)

    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles helpButton2.Click

        'The help message allows the client to identify what the purpose of the application is. This is present throughout 
        'using a 'messageBox.show()' command followed by the contents of the message in the string "".
        MessageBox.Show("Welcome to the virtual stock exchange,                    
                      
All the company records listed below can be filtered to a desired entity, in addition to using a spotlight search giving you the most efficient way to finding your desired investment

You can further select the Buy/Sell listing, transferring you to a selection page.")
    End Sub



    Private Sub ButtonClear_Click(sender As Object, e As EventArgs) Handles ButtonClear.Click

        'Because combo boxes have been used doesnt allow the program to assign the name to a '.clear()' action. Instead
        'the program needs to assign 'ButtonClear' with classing the string values as empty.

        'The program will then declare a new string field as there is no data in the comboBox so the client identifies what filters 
        'do what. 
        ComboBox2.Text = String.Empty
        ComboBox2.Text = "Company Name" 'declare a new string field

        ComboBox4.Text = String.Empty
        ComboBox4.Text = "Marketing Sector" 'declare a new string field

        ComboBox3.Text = String.Empty
        ComboBox3.Text = "Industry" 'declare a new string field

        ComboBox8.Text = String.Empty
        ComboBox8.Text = "Country" 'declare a new string field

        PEcomboBox.Text = String.Empty
        PEcomboBox.Text = "PE" 'declare a new string field

        ComboBox9.Text = String.Empty
        ComboBox9.Text = "Price" 'declare a new string field

        ComboBox5.Text = String.Empty
        ComboBox5.Text = "Volume" 'declare a new string field


    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles buySellButton.Click
        Form4.Show() 'Opening another form
        Me.Hide() 'Hides this form from the client
    End Sub

    Private Sub buyListing_Click(sender As Object, e As EventArgs) Handles buyListing.Click

        'The commands below assign the value of data in the filtered results to the textbox in 'FormBuy', making the data useful for 
        'The 'buy shares' event.

        FormBuy.Show()
        Me.Hide()
        ''.Text' allows the program to identify the data type that the text box gives as an output. 
        FormBuy.idPurchase.Text = TextBoxID.Text
        FormBuy.symbolPurchase.Text = TextBoxSymbol.Text
        FormBuy.namePurchase.Text = TextBoxCompanyName.Text
        FormBuy.sectorPurchase.Text = TextBoxMarketingSector.Text
        FormBuy.industryPurchase.Text = TextBoxIndustry.Text
        FormBuy.countryPurchase.Text = TextBoxCountry.Text
        FormBuy.pePurchase.Text = TextBoxPE.Text
        FormBuy.pricePurchase.Text = TextBoxPrice.Text
        FormBuy.changePurchase.Text = TextBoxChange.Text
        FormBuy.volumePurchase.Text = TextBoxVolume.Text
        FormBuy.MKtcapPurchase.Text = TextBoxMktCap.Text
        'Assigning all the text boxes to the required ones in the next form allows the client to use the data selected for 'query' to
        'Take these values, converting their character type to appropriate fields using 'Cint()' converting it into the correct data
        'Type for the query.

    End Sub
End Class

