﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Me.backSelection = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.addExchangeButton = New System.Windows.Forms.Button()
        Me.startingPriceSell = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.countrySell = New System.Windows.Forms.ComboBox()
        Me.industrySell = New System.Windows.Forms.ComboBox()
        Me.marketSectorSell = New System.Windows.Forms.ComboBox()
        Me.companyNameSell = New System.Windows.Forms.TextBox()
        Me.shareQuantitySell = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.symbolSell = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.IDSell = New System.Windows.Forms.TextBox()
        Me.mktcap = New System.Windows.Forms.Label()
        Me.MKtcapSell = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.PESell = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.changeSell = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label10 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.resetButton = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'backSelection
        '
        Me.backSelection.BackColor = System.Drawing.Color.Purple
        Me.backSelection.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.backSelection.Location = New System.Drawing.Point(44, 498)
        Me.backSelection.Name = "backSelection"
        Me.backSelection.Size = New System.Drawing.Size(107, 29)
        Me.backSelection.TabIndex = 111
        Me.backSelection.Text = "back"
        Me.backSelection.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.Purple
        Me.Button14.ForeColor = System.Drawing.SystemColors.Control
        Me.Button14.Location = New System.Drawing.Point(3, 3)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(39, 33)
        Me.Button14.TabIndex = 109
        Me.Button14.Text = "help"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(291, 132)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(75, 13)
        Me.Label17.TabIndex = 108
        Me.Label17.Text = "local date,time"
        '
        'addExchangeButton
        '
        Me.addExchangeButton.BackColor = System.Drawing.Color.Green
        Me.addExchangeButton.ForeColor = System.Drawing.SystemColors.Control
        Me.addExchangeButton.Location = New System.Drawing.Point(151, 498)
        Me.addExchangeButton.Name = "addExchangeButton"
        Me.addExchangeButton.Size = New System.Drawing.Size(107, 29)
        Me.addExchangeButton.TabIndex = 99
        Me.addExchangeButton.Text = "add to exchange"
        Me.addExchangeButton.UseVisualStyleBackColor = False
        '
        'startingPriceSell
        '
        Me.startingPriceSell.Location = New System.Drawing.Point(207, 373)
        Me.startingPriceSell.Name = "startingPriceSell"
        Me.startingPriceSell.Size = New System.Drawing.Size(51, 20)
        Me.startingPriceSell.TabIndex = 92
        Me.startingPriceSell.Text = "100"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(41, 246)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 13)
        Me.Label2.TabIndex = 112
        Me.Label2.Text = "Company name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(41, 273)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 113
        Me.Label3.Text = "Marketing sector"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(41, 427)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(76, 13)
        Me.Label9.TabIndex = 119
        Me.Label9.Text = "share quantity "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(41, 380)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 13)
        Me.Label7.TabIndex = 117
        Me.Label7.Text = "starting price"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(42, 328)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(43, 13)
        Me.Label6.TabIndex = 116
        Me.Label6.Text = "Country"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(41, 301)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 115
        Me.Label5.Text = "Industry"
        '
        'countrySell
        '
        Me.countrySell.FormattingEnabled = True
        Me.countrySell.Location = New System.Drawing.Point(207, 320)
        Me.countrySell.Name = "countrySell"
        Me.countrySell.Size = New System.Drawing.Size(66, 21)
        Me.countrySell.TabIndex = 120
        Me.countrySell.Text = "select"
        '
        'industrySell
        '
        Me.industrySell.FormattingEnabled = True
        Me.industrySell.Location = New System.Drawing.Point(207, 293)
        Me.industrySell.Name = "industrySell"
        Me.industrySell.Size = New System.Drawing.Size(66, 21)
        Me.industrySell.TabIndex = 121
        Me.industrySell.Text = "select"
        '
        'marketSectorSell
        '
        Me.marketSectorSell.FormattingEnabled = True
        Me.marketSectorSell.Location = New System.Drawing.Point(207, 265)
        Me.marketSectorSell.Name = "marketSectorSell"
        Me.marketSectorSell.Size = New System.Drawing.Size(159, 21)
        Me.marketSectorSell.TabIndex = 122
        Me.marketSectorSell.Text = "select"
        '
        'companyNameSell
        '
        Me.companyNameSell.Location = New System.Drawing.Point(207, 239)
        Me.companyNameSell.Name = "companyNameSell"
        Me.companyNameSell.Size = New System.Drawing.Size(159, 20)
        Me.companyNameSell.TabIndex = 123
        Me.companyNameSell.Text = "testcmp"
        '
        'shareQuantitySell
        '
        Me.shareQuantitySell.Location = New System.Drawing.Point(207, 420)
        Me.shareQuantitySell.Name = "shareQuantitySell"
        Me.shareQuantitySell.Size = New System.Drawing.Size(51, 20)
        Me.shareQuantitySell.TabIndex = 124
        Me.shareQuantitySell.Text = "25"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Purple
        Me.Label18.Location = New System.Drawing.Point(40, 88)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(347, 25)
        Me.Label18.TabIndex = 127
        Me.Label18.Text = "Virtual stock exchange sell shares "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(42, 218)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 128
        Me.Label4.Text = "symbol"
        '
        'symbolSell
        '
        Me.symbolSell.Location = New System.Drawing.Point(207, 211)
        Me.symbolSell.Name = "symbolSell"
        Me.symbolSell.Size = New System.Drawing.Size(57, 20)
        Me.symbolSell.TabIndex = 129
        Me.symbolSell.Text = "test"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(42, 191)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(18, 13)
        Me.Label8.TabIndex = 130
        Me.Label8.Text = "ID"
        '
        'IDSell
        '
        Me.IDSell.Location = New System.Drawing.Point(207, 184)
        Me.IDSell.Name = "IDSell"
        Me.IDSell.Size = New System.Drawing.Size(35, 20)
        Me.IDSell.TabIndex = 131
        Me.IDSell.Text = "21"
        '
        'mktcap
        '
        Me.mktcap.AutoSize = True
        Me.mktcap.Location = New System.Drawing.Point(42, 454)
        Me.mktcap.Name = "mktcap"
        Me.mktcap.Size = New System.Drawing.Size(63, 13)
        Me.mktcap.TabIndex = 132
        Me.mktcap.Text = "MKt cap (B)"
        '
        'MKtcapSell
        '
        Me.MKtcapSell.Location = New System.Drawing.Point(207, 447)
        Me.MKtcapSell.Name = "MKtcapSell"
        Me.MKtcapSell.Size = New System.Drawing.Size(51, 20)
        Me.MKtcapSell.TabIndex = 134
        Me.MKtcapSell.Text = "200"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(41, 354)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(26, 13)
        Me.Label12.TabIndex = 136
        Me.Label12.Text = "P/E"
        '
        'PESell
        '
        Me.PESell.Location = New System.Drawing.Point(207, 347)
        Me.PESell.Name = "PESell"
        Me.PESell.Size = New System.Drawing.Size(51, 20)
        Me.PESell.TabIndex = 137
        Me.PESell.Text = "0.2"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 404)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 138
        Me.Label1.Text = "change%"
        '
        'changeSell
        '
        Me.changeSell.Location = New System.Drawing.Point(207, 397)
        Me.changeSell.Name = "changeSell"
        Me.changeSell.Size = New System.Drawing.Size(51, 20)
        Me.changeSell.TabIndex = 139
        Me.changeSell.Text = "20"
        '
        'Timer1
        '
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Purple
        Me.Label10.Location = New System.Drawing.Point(39, 132)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(126, 25)
        Me.Label10.TabIndex = 140
        Me.Label10.Text = "Sell shares "
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(44, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 81)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 141
        Me.PictureBox1.TabStop = False
        '
        'resetButton
        '
        Me.resetButton.BackColor = System.Drawing.Color.Purple
        Me.resetButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.resetButton.Location = New System.Drawing.Point(259, 498)
        Me.resetButton.Name = "resetButton"
        Me.resetButton.Size = New System.Drawing.Size(107, 29)
        Me.resetButton.TabIndex = 142
        Me.resetButton.Text = "reset"
        Me.resetButton.UseVisualStyleBackColor = False
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(411, 539)
        Me.Controls.Add(Me.resetButton)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.changeSell)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PESell)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.MKtcapSell)
        Me.Controls.Add(Me.mktcap)
        Me.Controls.Add(Me.IDSell)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.symbolSell)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.shareQuantitySell)
        Me.Controls.Add(Me.companyNameSell)
        Me.Controls.Add(Me.marketSectorSell)
        Me.Controls.Add(Me.industrySell)
        Me.Controls.Add(Me.countrySell)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.backSelection)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.addExchangeButton)
        Me.Controls.Add(Me.startingPriceSell)
        Me.Name = "Form5"
        Me.Text = "Form5"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents backSelection As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents addExchangeButton As Button
    Friend WithEvents startingPriceSell As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents countrySell As ComboBox
    Friend WithEvents industrySell As ComboBox
    Friend WithEvents marketSectorSell As ComboBox
    Friend WithEvents companyNameSell As TextBox
    Friend WithEvents shareQuantitySell As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents symbolSell As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents IDSell As TextBox
    Friend WithEvents mktcap As Label
    Friend WithEvents MKtcapSell As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents PESell As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents changeSell As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents resetButton As Button
End Class
