﻿'Importing mysql data in order for manipulation of data.
Imports MySql.Data.MySqlClient

Public Class Form5 'Add listing
    'Declaring all key MySql variables used to manipulate data.
    Dim connection As New MySqlConnection("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
    Dim COMMAND As MySqlCommand


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles backSelection.Click
        Form4.Show() 'Shows the selection page
        Me.Hide() 'Hides the sell shares page.
    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True 'Enables the state of timer1.

        connection = New MySqlConnection 'New sql connection used to connect to the database.
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader 'Declaring the ability to read from database in order to retreive when using query.


        'Data for market Sector
        Try
            connection.Open() 'Connection is open allowing manipulation.
            Dim Query As String 'Declaring 'Query' as string.
            'Selecting distinct 'column name' allows there to be no repeating data followed by the location of the database.
            Query = "select distinct marketSector from stockexchange.virtualexchange"
            'The value of Query and Connection are passed into command within Try block and uses this to send to the data
            'base stating what the purpose of the request COMMAND is, to provide query and the connection the data will be 
            'going to.
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader 'READER delcared as the command in order to execute.


            While READER.Read
                'Within the while loop, variable mSectorSell is declared and assigned its equivalent mySQL 'marketSector'
                Dim mSectorSell = READER.GetString("marketSector")
                marketSectorSell.Items.Add(mSectorSell) 'Adds the item to the form in selection box.


            End While

            connection.Close() 'Closing the connection.

        Catch ex As MySqlException
            MessageBox.Show(ex.Message) ' Catches any errors that may arise.
        Finally
            connection.Dispose()
        End Try

        'Data for Industry (Try block similar to first)

        Try
            connection.Open()
            Dim Query As String
            Query = "select distinct industry from stockexchange.virtualexchange"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader


            While READER.Read

                Dim iSell = READER.GetString("industry")
                industrySell.Items.Add(iSell)


            End While

            connection.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try

        'Data for Country (Try block similar to first)
        Try
            connection.Open()
            Dim Query As String
            Query = "select distinct country from stockexchange.virtualexchange"
            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader


            While READER.Read

                Dim ctry = READER.GetString("country")
                countrySell.Items.Add(ctry)


            End While

            connection.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub addExchangeButton_Click(sender As Object, e As EventArgs) Handles addExchangeButton.Click
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        Dim READER As MySqlDataReader

        Try

            connection.Open()
            Dim Query As String
            'This query is responsible for inserting the new data that the client enters into the form, into the database. Firstly the column names are referenced for 'into'
            'To identify where the new items will be going, relating to the order. Next 'values' is used and includes all the values to be inserted in the correct order of
            'Reference. The conversion 'Cint' for example is responsible for the correct datatypes to be retrieved from the textbox for the database.
            Query = "insert into stockexchange.virtualexchange (ID,symbol, companyName, marketSector, industry, country, PE, price£, percentageChange, volume, MKtcapB) values (" & CInt(IDSell.Text) & ",'" & symbolSell.Text & "','" & companyNameSell.Text & "','" & marketSectorSell.Text & "','" & industrySell.Text & "','" & countrySell.Text & "'," & CSng(PESell.Text) & "," & CSng(startingPriceSell.Text) & "," & CSng(changeSell.Text) & "," & CInt(shareQuantitySell.Text) & "," & CSng(MKtcapSell.Text) & ")"


            COMMAND = New MySqlCommand(Query, connection)
            READER = COMMAND.ExecuteReader

            Form6.Show() 'The 'success' form is presented when the query has been executed with no errors, showing that new data has been added. 
            connection.Close()
            Me.Hide()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)

            Form7.Show()
            Me.Hide()
        Finally
            connection.Dispose()
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label17.Text = Date.Now.ToString("dd-MM-yyyy  hh:mm:ss") 'Responsible for presenting date and time to the client within the form.
    End Sub

    Private Sub resetButton_Click(sender As Object, e As EventArgs) Handles resetButton.Click
        'The reset button clears all the text box values allowing the client the ability to enter new data they wish to add to the 
        'exchange. '.Clear' removes any text from the textbox.
        IDSell.Clear()
        symbolSell.Clear()
        companyNameSell.Clear()
        PESell.Clear()
        startingPriceSell.Clear()
        changeSell.Clear()
        shareQuantitySell.Clear()
        MKtcapSell.Clear()

        'For the combo box, the contents is emptied using 'string.empty' and 'select' is replaced.
        marketSectorSell.Text = String.Empty
        marketSectorSell.Text = "select"

        industrySell.Text = String.Empty
        industrySell.Text = "select"

        countrySell.Text = String.Empty
        countrySell.Text = "select"
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        'This help message gives the client instructions on how to use this form.
        MessageBox.Show("The prompts below require you to select all appropriate fields in order to add a listing to the virtual exchange. If you have made an error/entered an incorrect listing, before pressing add to exchange press the 'reset' button' and you can start a new selection")
    End Sub
End Class