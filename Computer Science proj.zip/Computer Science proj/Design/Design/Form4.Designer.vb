﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.sellListing = New System.Windows.Forms.Button()
        Me.backButton = New System.Windows.Forms.Button()
        Me.helpButton4 = New System.Windows.Forms.Button()
        Me.removeListing = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label14 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'sellListing
        '
        Me.sellListing.BackColor = System.Drawing.Color.Purple
        Me.sellListing.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.sellListing.Location = New System.Drawing.Point(65, 87)
        Me.sellListing.Name = "sellListing"
        Me.sellListing.Size = New System.Drawing.Size(126, 146)
        Me.sellListing.TabIndex = 10
        Me.sellListing.Text = "Sell"
        Me.sellListing.UseVisualStyleBackColor = False
        '
        'backButton
        '
        Me.backButton.BackColor = System.Drawing.Color.Purple
        Me.backButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.backButton.Location = New System.Drawing.Point(131, 276)
        Me.backButton.Name = "backButton"
        Me.backButton.Size = New System.Drawing.Size(111, 31)
        Me.backButton.TabIndex = 11
        Me.backButton.Text = "back"
        Me.backButton.UseVisualStyleBackColor = False
        '
        'helpButton4
        '
        Me.helpButton4.BackColor = System.Drawing.Color.Red
        Me.helpButton4.ForeColor = System.Drawing.SystemColors.Control
        Me.helpButton4.Location = New System.Drawing.Point(314, 1)
        Me.helpButton4.Name = "helpButton4"
        Me.helpButton4.Size = New System.Drawing.Size(39, 33)
        Me.helpButton4.TabIndex = 76
        Me.helpButton4.Text = "help"
        Me.helpButton4.UseVisualStyleBackColor = False
        '
        'removeListing
        '
        Me.removeListing.BackColor = System.Drawing.Color.Purple
        Me.removeListing.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.removeListing.Location = New System.Drawing.Point(190, 87)
        Me.removeListing.Name = "removeListing"
        Me.removeListing.Size = New System.Drawing.Size(126, 146)
        Me.removeListing.TabIndex = 79
        Me.removeListing.Text = "remove a listing"
        Me.removeListing.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 84)
        Me.PictureBox1.TabIndex = 80
        Me.PictureBox1.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Purple
        Me.Label14.Location = New System.Drawing.Point(110, 35)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(174, 25)
        Me.Label14.TabIndex = 81
        Me.Label14.Text = "make a selection"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(365, 309)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.removeListing)
        Me.Controls.Add(Me.helpButton4)
        Me.Controls.Add(Me.backButton)
        Me.Controls.Add(Me.sellListing)
        Me.Name = "Form4"
        Me.Text = "Form4"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents sellListing As Button
    Friend WithEvents backButton As Button
    Friend WithEvents helpButton4 As Button
    Friend WithEvents removeListing As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label14 As Label
End Class
