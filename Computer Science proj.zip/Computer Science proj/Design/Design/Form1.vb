﻿'This line of code fetches relevant mySQL data from the reference mysql.data.dll i added.
Imports MySql.Data.MySqlClient

Public Class Form1 'Login
    'Declaring the connection to mySQL database as a MySqlConnection, identifying how the string will be used.
    Dim connection As MySqlConnection
    'This takes both 'Query,connection' and assigns these to COMMAND later on in the program. Declaring this prior allows the retieval to the database to occur.
    Dim COMMAND As MySqlCommand

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles submit.Click

        'Declaring the connection as a string, then referencing MySql database using userid and password along with the database name.
        connection = New MySqlConnection
        connection.ConnectionString = ("server=localhost;userid=root;password=sqlLukeDB;database=stockexchange")
        'Declaring the ability to read from database in order to retreive when using query.
        Dim READER As MySqlDataReader


        'Sets out what the program should execute within 'try' including opening connection to database, assigning Query as a string then using that to parse the correct query contents used for database.
        Try

            connection.Open()
            Dim Query As String

            'The Query involves selecting column names from database name.table name. Then a where clause to identify what textbox values 
            'in the form equate to what mySQL values, this is done by assigning the textbox value to the column name around '"

            Query = "SELECT userName,bankOrganisation,securityKey FROM stockExchange.login WHERE userName = '" & TextBoxuserName.Text & "' And bankOrganisation = 
             '" & TextBoxbankOrganisation.Text & "' and securityKey = '" & TextBoxsecurityKey.Text & "'"

            'This is sent to the database including both the query and the command so the logic understands where it needs to go and how to use queries for the data.
            COMMAND = New MySqlCommand(Query, connection)

            READER = COMMAND.ExecuteReader

            'The purpose of the while loop is to determine a correct/incorrect input and will display the appropriate messagebox.
            Dim count As Integer
            count = 0
            While READER.Read
                count = count + 1
                'Count' refers to how many attempts the query requested for correct information the client entered, if this 
                'is correct, being read by READER once, messagebox 'correct' will display.
            End While
            If count = 1 Then
                'If the READER cannot identify correct column entries that equal mySQL values, it will read this again and 
                'Identify again if any values are correct/incorrect, otherwise the program will most likely predsent 'duplicate
                'entires'

                MessageBox.Show("Correct user details")
                'Opens the virtual exchange form where the client can continue the use of application.
                Form2.Show()
                'This will make this form invisible allowing no secondary entries to be made to the exchange under a certain name
                Me.Hide()
            ElseIf count > 1 Then
                MessageBox.Show("More than one field contains a duplicate")
            Else
                'When the values entered by the user are completely inacurate, an error message will be displayed.
                MessageBox.Show("Incorrect entries")

            End If
            'Closing the connection as it is no longer needed. Necessary to free up processing space on local machine as 
            'excess computation to keep mySQL server open is needed, therefore limiting perormance of the database.
            connection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            'This is to stop the login table data retrieval if the connection is still open, reducing processing
            'time.
            connection.Dispose()

        End Try

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Refreshes all entry fields if the client wants to make a new entry without submission.
        '.Clear wipes the text box clear of any pre existing entries.
        TextBoxuserName.Clear()
        TextBoxbankOrganisation.Clear()
        TextBoxsecurityKey.Clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'Exits from the quit button.
        Close()

    End Sub

    Private Sub Label5_Click_1(sender As Object, e As EventArgs)

    End Sub
End Class
