import java.util.ArrayList;
public class coins
{
    
public String toString ()
{ 
   coinForm command = coinForm.ONE_PENNY;
   coinForm command2= coinForm.TWO_PENCE;
   coinForm command3= coinForm.FIVE_PENCE;
   coinForm command4= coinForm.TEN_PENCE;
   coinForm command5= coinForm.TWENTY_PENCE;
   coinForm command6= coinForm.FIFTY_PENCE;
   coinForm command7= coinForm.ONE_POUND;
   coinForm command8= coinForm.TWO_POUNDS;
        
            switch(command)
         
            {
               case ONE_PENNY:
               System.out.println("one penny");
               
            }    
            switch(command2)  
            {
            case TWO_PENCE:
               System.out.println("two pence");
                
            }
            switch(command3)     
            {
            case FIVE_PENCE:
                System.out.println("five pence");
               
            }
            switch(command4)     
            {
                case TEN_PENCE:
                System.out.println("ten pence");
              
            }
            switch(command5)     
            {
                case TWENTY_PENCE:
                System.out.println("twenty pence");
               
            }
            switch(command6)     
            {
                case FIFTY_PENCE:
                System.out.println("fifty pence");
              
            }
            switch(command7)     
            {
                case ONE_POUND:
               System.out.println("one pound");
              
            }
            switch(command8)     
            {
                case TWO_POUNDS:
                System.out.println("two pounds");
              
            }
            return ("List of coins");
             }
}   
      
   
