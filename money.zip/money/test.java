import java.util.ArrayList;
public class test
{
   public void printCoins()
             {
                ArrayList coinTotal = new ArrayList();
                float coinSum = 0;
               
                 coinTotal.add(coinForm.ONE_PENNY.getValue());
                 coinSum = coinSum + (coinForm.ONE_PENNY.getValue());
                 coinTotal.add(coinForm.FIFTY_PENCE.getValue());
                 coinSum = coinSum + (coinForm.FIFTY_PENCE.getValue());
                 coinTotal.add(coinForm.TWO_POUNDS.getValue());
                 coinSum = coinSum + (coinForm.TWO_POUNDS.getValue());
                 coinTotal.add(coinForm.ONE_POUND.getValue());
                 coinSum = coinSum + (coinForm.ONE_POUND.getValue());
                 coinTotal.add(coinForm.TEN_PENCE.getValue());
                 coinSum = coinSum + (coinForm.TEN_PENCE.getValue());
         
                 System.out.println(coinTotal);
                 System.out.println("");
                 System.out.println("The total for coins: £ " + coinSum/100);
                }
}
