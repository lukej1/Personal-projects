﻿Public Class Form1
    Function Caesar_Cipher(ByVal Text As String, ByVal N As Integer, ByVal Encrypt As Boolean)
        Dim Result As String = ""

        For Each c As Char In Text
            Dim x As Integer
            If Encrypt Then
                x = Asc(c) + N
            Else
                x = Asc(c) + 26 - N
            End If

            If Char.IsLower(c) Then
                If x > Asc("z") Then
                    x -= 26
                End If
                Result += Chr(x)

            ElseIf Char.IsUpper(c) Then
                If x > Asc("Z") Then
                    x -= 26
                End If
                Result += Chr(x)
            Else
                Result += c
            End If

        Next




        Return Result
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox2.Text = Caesar_Cipher(TextBox1.Text, NumericUpDown1.Value, False)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = Caesar_Cipher(TextBox2.Text, NumericUpDown1.Value, True)
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
