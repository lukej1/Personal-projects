﻿Module Module1

    Sub Main()
        Dim a, b, c, d, e, f, g As Boolean

        a = 23 > 14 And 11 > 8
        b = 14 > 23 And 11 > 8

        Console.WriteLine(a & b)
        Console.ReadLine()



        c = 23 > 14 Or 8 > 11
        d = 23 > 67 Or 8 > 11

        Console.WriteLine(c & d)
        Console.ReadLine()

        e = 23 > 67 Xor 11 > 8
        f = 23 > 14 Xor 11 > 8
        g = 14 > 23 Xor 8 > 11

        Console.WriteLine(e & f & g)
        Console.ReadLine()

        Dim x, y As Boolean
        x = Not 23 > 14
        y = Not 23 > 67

        Console.WriteLine(x & y)
        Console.ReadLine()

    End Sub

End Module
